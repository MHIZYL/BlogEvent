import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';

interface UserProfile {
  uid: string;
  name: string;
  email: string;
  profileImage: string;
  role: 'admin' | 'editor' | 'user';
  createdAt: string;
  savedEvents: string[];
  registeredEvents: string[];
  notificationsEnabled: boolean;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubProfile: () => void;

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (currentUser) {
        const userRef = doc(db, 'users', currentUser.uid);
        
        try {
          const docSnap = await getDoc(userRef);
          
          if (!docSnap.exists()) {
            // Create user profile if it doesn't exist
            const isAdmin = currentUser.email === 'armhildelacruz12@gmail.com';
            const newProfile: UserProfile = {
              uid: currentUser.uid,
              name: currentUser.displayName || 'User',
              email: currentUser.email || '',
              profileImage: currentUser.photoURL || '',
              role: isAdmin ? 'admin' : 'user', // Default role
              createdAt: new Date().toISOString(),
              savedEvents: [],
              registeredEvents: [],
              notificationsEnabled: true
            };
            
            await setDoc(userRef, newProfile);
            setProfile(newProfile);
          } else {
            const existingProfile = docSnap.data() as UserProfile;
            if (currentUser.email === 'armhildelacruz12@gmail.com' && existingProfile.role !== 'admin') {
              existingProfile.role = 'admin';
              await setDoc(userRef, { role: 'admin' }, { merge: true });
            }
            setProfile(existingProfile);
          }
        } catch (error) {
          console.error("Error fetching user profile:", error);
        }

        // Listen for profile changes
        unsubProfile = onSnapshot(userRef, (doc) => {
          if (doc.exists()) {
            setProfile(doc.data() as UserProfile);
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
        });

        setLoading(false);
      } else {
        setProfile(null);
        setLoading(false);
        if (unsubProfile) unsubProfile();
      }
    });

    return () => {
      unsubscribe();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const signInWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Error signing in with Google", error);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, signInWithGoogle, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
