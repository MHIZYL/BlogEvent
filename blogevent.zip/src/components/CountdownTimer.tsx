import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  date: string;
  time: string;
  onComplete?: () => void;
}

export default function CountdownTimer({ date, time, onComplete }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const eventDate = new Date(`${date}T${time || '00:00:00'}`).getTime();

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = eventDate - now;

      if (distance < 0) {
        clearInterval(timer);
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (!isCompleted) {
          setIsCompleted(true);
          if (onComplete) onComplete();
        }
      } else {
        setTimeLeft({
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        });
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [date, time, isCompleted, onComplete]);

  if (isCompleted) {
    return (
      <div className="bg-green-100 text-green-800 px-6 py-4 rounded-xl text-center font-bold text-lg border border-green-200">
        Event has started!
      </div>
    );
  }

  return (
    <div className="flex justify-center gap-2 sm:gap-4">
      <div className="flex flex-col items-center">
        <div className="bg-white text-indigo-600 rounded-lg w-14 h-14 sm:w-20 sm:h-20 flex items-center justify-center text-xl sm:text-3xl font-bold shadow-md border border-indigo-100">
          {timeLeft.days}
        </div>
        <span className="text-gray-500 mt-1 text-xs sm:text-sm font-medium uppercase tracking-wider">Days</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="bg-white text-indigo-600 rounded-lg w-14 h-14 sm:w-20 sm:h-20 flex items-center justify-center text-xl sm:text-3xl font-bold shadow-md border border-indigo-100">
          {timeLeft.hours}
        </div>
        <span className="text-gray-500 mt-1 text-xs sm:text-sm font-medium uppercase tracking-wider">Hours</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="bg-white text-indigo-600 rounded-lg w-14 h-14 sm:w-20 sm:h-20 flex items-center justify-center text-xl sm:text-3xl font-bold shadow-md border border-indigo-100">
          {timeLeft.minutes}
        </div>
        <span className="text-gray-500 mt-1 text-xs sm:text-sm font-medium uppercase tracking-wider">Mins</span>
      </div>
      <div className="flex flex-col items-center">
        <div className="bg-white text-indigo-600 rounded-lg w-14 h-14 sm:w-20 sm:h-20 flex items-center justify-center text-xl sm:text-3xl font-bold shadow-md border border-indigo-100">
          {timeLeft.seconds}
        </div>
        <span className="text-gray-500 mt-1 text-xs sm:text-sm font-medium uppercase tracking-wider">Secs</span>
      </div>
    </div>
  );
}
