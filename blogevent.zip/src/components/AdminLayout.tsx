import { useState } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { LayoutDashboard, Calendar, FileText, Users, Settings, LogOut, Home, Image as ImageIcon, MessageSquare, Sun, Moon } from 'lucide-react';
import { clsx } from 'clsx';
import LogoutConfirmation from './LogoutConfirmation';

export default function AdminLayout() {
  const { profile, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const navigation = [
    { name: 'Dashboard', href: '/admin', icon: LayoutDashboard },
    { name: 'Events', href: '/admin/events', icon: Calendar },
    { name: 'Blogs', href: '/admin/blogs', icon: FileText },
    { name: 'Comments', href: '/admin/comments', icon: MessageSquare },
    { name: 'Media Library', href: '/admin/media', icon: ImageIcon },
    { name: 'Users', href: '/admin/users', icon: Users, adminOnly: true },
    { name: 'Settings', href: '/admin/settings', icon: Settings, adminOnly: true },
  ];

  return (
    <div className="h-screen flex bg-gray-100 dark:bg-dark-bg overflow-hidden transition-colors duration-300">
      {/* Sidebar */}
      <div className="w-64 bg-gray-900 dark:bg-black text-white flex flex-col h-full border-r dark:border-dark-border">
        <div className="h-16 flex items-center px-6 bg-gray-950 flex-shrink-0 border-b dark:border-dark-border">
          <Calendar className="h-8 w-8 text-indigo-500 mr-2" />
          <span className="text-xl font-bold">Admin Panel</span>
        </div>
        
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-3 space-y-1">
            {navigation.map((item) => {
              if (item.adminOnly && profile?.role !== 'admin') return null;
              
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={clsx(
                    isActive ? 'bg-gray-800 text-white' : 'text-gray-300 hover:bg-gray-800 hover:text-white',
                    'group flex items-center px-3 py-2 text-sm font-medium rounded-md'
                  )}
                >
                  <item.icon className={clsx(
                    isActive ? 'text-indigo-400' : 'text-gray-400 group-hover:text-gray-300',
                    'flex-shrink-0 -ml-1 mr-3 h-6 w-6'
                  )} />
                  <span className="truncate">{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-gray-800 flex-shrink-0">
          <div className="flex items-center gap-3 mb-4">
            <img src={profile?.profileImage || `https://ui-avatars.com/api/?name=${profile?.name}`} alt="" className="w-10 h-10 rounded-full bg-gray-800" />
            <div className="overflow-hidden">
              <p className="text-sm font-medium text-white truncate">{profile?.name}</p>
              <p className="text-xs text-gray-400 capitalize">{profile?.role}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Link to="/" className="flex-1 flex justify-center items-center py-2 px-3 bg-gray-800 hover:bg-gray-700 rounded-md text-sm text-gray-300 transition-colors">
              <Home className="w-4 h-4 mr-2" />
              Site
            </Link>
            <button 
              onClick={() => setShowLogoutConfirm(true)} 
              className="flex-1 flex justify-center items-center py-2 px-3 bg-red-900/50 hover:bg-red-900/80 text-red-200 rounded-md text-sm transition-colors"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Exit
            </button>
          </div>
        </div>
      </div>

      {/* Logout Confirmation Modal */}
      <LogoutConfirmation 
        isOpen={showLogoutConfirm} 
        onClose={() => setShowLogoutConfirm(false)} 
        onConfirm={logout} 
      />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white dark:bg-dark-surface shadow-sm h-16 flex items-center px-8 border-b dark:border-dark-border">
          <div className="flex-1">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
              {navigation.find(n => n.href === location.pathname)?.name || 'Admin'}
            </h1>
          </div>
          <button
            onClick={toggleTheme}
            className="p-2 text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
          >
            {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
          </button>
        </header>
        <main className="flex-1 overflow-y-auto p-8 dark:bg-dark-bg">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
