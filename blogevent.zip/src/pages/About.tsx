export default function About() {
  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">About Us</h1>
      <div className="prose max-w-none text-gray-500">
        <p>Welcome to BlogEvent, your premier destination for discovering and managing events.</p>
      </div>
    </div>
  );
}
