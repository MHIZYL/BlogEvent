import { useState, useEffect, useRef } from 'react';
import { Upload, Image as ImageIcon, Trash2, Link as LinkIcon } from 'lucide-react';
import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { collection, addDoc, deleteDoc, doc, onSnapshot, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { db, storage } from '../../firebase';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';

interface MediaItem {
  id: string;
  url: string;
  name: string;
  size: string;
  date: string;
  path: string;
}

export default function MediaLibrary() {
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const q = query(collection(db, 'media'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const mediaData = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          id: doc.id,
          url: data.url,
          name: data.name,
          size: data.size,
          date: data.createdAt?.toDate().toLocaleDateString() || new Date().toLocaleDateString(),
          path: data.path
        };
      }) as MediaItem[];
      setMedia(mediaData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'media');
    });

    return () => unsubscribe();
  }, []);

  const formatBytes = (bytes: number, decimals = 2) => {
    if (!+bytes) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadProgress(0);

    const storageRef = ref(storage, `media/${Date.now()}_${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on('state_changed', 
      (snapshot) => {
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        setUploadProgress(progress);
      }, 
      (error) => {
        console.error("Upload failed:", error);
        alert("Upload failed. Please try again.");
        setUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }, 
      async () => {
        try {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          await addDoc(collection(db, 'media'), {
            url: downloadURL,
            name: file.name,
            size: formatBytes(file.size),
            path: uploadTask.snapshot.ref.fullPath,
            createdAt: serverTimestamp()
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.CREATE, 'media');
        } finally {
          setUploading(false);
          setUploadProgress(0);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      }
    );
  };

  const handleDelete = async (item: MediaItem) => {
    if (window.confirm('Are you sure you want to delete this image?')) {
      try {
        // Delete from Storage
        if (item.path) {
          const storageRef = ref(storage, item.path);
          await deleteObject(storageRef);
        }
        // Delete from Firestore
        await deleteDoc(doc(db, 'media', item.id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `media/${item.id}`);
      }
    }
  };

  const copyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    alert('Link copied to clipboard!');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900">Media Library</h2>
        <div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileSelect} 
            accept="image/*" 
            className="hidden" 
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            <Upload className="w-4 h-4 mr-2" />
            {uploading ? `Uploading... ${Math.round(uploadProgress)}%` : 'Upload Image'}
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        {media.length === 0 ? (
          <div className="text-center py-12">
            <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-900">No media</h3>
            <p className="mt-1 text-sm text-gray-500">Get started by uploading an image.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 sm:gap-x-6 lg:grid-cols-4 xl:gap-x-8">
            {media.map((item) => (
              <div key={item.id} className="relative">
                <div className="group block w-full aspect-w-10 aspect-h-7 rounded-lg bg-gray-100 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-gray-100 focus-within:ring-indigo-500 overflow-hidden">
                  <img src={item.url} alt="" className="object-cover pointer-events-none group-hover:opacity-75 h-40 w-full" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black bg-opacity-40 gap-2">
                    <button 
                      onClick={() => copyLink(item.url)}
                      className="p-2 bg-white rounded-full text-gray-700 hover:text-indigo-600 transition-colors"
                      title="Copy Link"
                    >
                      <LinkIcon className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(item)}
                      className="p-2 bg-white rounded-full text-gray-700 hover:text-red-600 transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <p className="mt-2 block text-sm font-medium text-gray-900 truncate pointer-events-none">{item.name}</p>
                <p className="block text-sm font-medium text-gray-500 pointer-events-none">{item.size}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
