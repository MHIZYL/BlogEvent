import React, { useState, useEffect, useRef } from 'react';
import { collection, query, onSnapshot, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase';
import { useAuth } from '../../contexts/AuthContext';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';
import { FileText, Trash2, Edit, Upload, X } from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  categoryId: string;
  status: 'published' | 'draft' | 'scheduled';
  authorId: string;
  createdAt: string;
  featuredImage?: string;
  gallery?: string[];
}

export default function AdminBlogs() {
  const { profile } = useAuth();
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<any>({
    title: '',
    content: '',
    categoryId: 'general',
    status: 'published' as const,
  });

  const [featuredImageFile, setFeaturedImageFile] = useState<File | null>(null);
  const [galleryFiles, setGalleryFiles] = useState<File[]>([]);

  const featuredImageInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const q = query(collection(db, 'blog_posts'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const blogsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as BlogPost[];
      setBlogs(blogsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'blog_posts');
    });

    return () => unsubscribe();
  }, []);

  const handleFeaturedImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFeaturedImageFile(e.target.files[0]);
    }
  };

  const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setGalleryFiles(prev => [...prev, ...Array.from(e.target.files!)]);
    }
  };

  const removeGalleryFile = (index: number) => {
    setGalleryFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    setIsUploading(true);

    try {
      let featuredImageUrl = formData.featuredImage || '';
      if (featuredImageFile) {
        const storageRef = ref(storage, `blogs/featured/${Date.now()}_${featuredImageFile.name}`);
        await uploadBytes(storageRef, featuredImageFile);
        featuredImageUrl = await getDownloadURL(storageRef);
      }

      const galleryUrls: string[] = formData.gallery || [];
      for (const file of galleryFiles) {
        const storageRef = ref(storage, `blogs/gallery/${Date.now()}_${file.name}`);
        await uploadBytes(storageRef, file);
        const url = await getDownloadURL(storageRef);
        galleryUrls.push(url);
      }

      const blogData = {
        title: formData.title || '',
        content: formData.content || '',
        categoryId: formData.categoryId || 'general',
        status: formData.status || 'published',
        featuredImage: featuredImageUrl,
        gallery: galleryUrls,
        authorId: profile.uid,
        createdAt: editingId ? (formData.createdAt || new Date().toISOString()) : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        views: editingId ? (formData.views || 0) : 0,
        tags: formData.tags || []
      };

      if (editingId) {
        await updateDoc(doc(db, 'blog_posts', editingId), blogData);
        alert('Blog post updated successfully!');
      } else {
        await addDoc(collection(db, 'blog_posts'), blogData);
        alert('Blog post created successfully!');
      }
      
      setIsFormOpen(false);
      setEditingId(null);
      setFormData({ title: '', content: '', categoryId: 'general', status: 'published' });
      setFeaturedImageFile(null);
      setGalleryFiles([]);
      if (featuredImageInputRef.current) featuredImageInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    } catch (error) {
      const errorMsg = handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, 'blog_posts');
      alert(`Error saving blog post: ${JSON.parse(errorMsg).error}`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleEdit = (blog: BlogPost) => {
    const { id, ...rest } = blog;
    setEditingId(id);
    setFormData(rest);
    setIsFormOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this blog post?')) {
      try {
        await deleteDoc(doc(db, 'blog_posts', id));
        alert('Blog post deleted successfully!');
      } catch (error) {
        const errorMsg = handleFirestoreError(error, OperationType.DELETE, `blog_posts/${id}`);
        alert(`Error deleting blog post: ${JSON.parse(errorMsg).error}`);
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Manage Blogs</h2>
        <button 
          onClick={() => {
            if (isFormOpen) {
              setEditingId(null);
              setFormData({ title: '', content: '', categoryId: 'general', status: 'published' });
            }
            setIsFormOpen(!isFormOpen);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
        >
          {isFormOpen ? 'Cancel' : 'Add Blog Post'}
        </button>
      </div>

      {isFormOpen && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
          <h3 className="text-lg font-medium mb-4">{editingId ? 'Edit Blog Post' : 'Create New Blog Post'}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Title</label>
              <input type="text" required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Content</label>
              <textarea required rows={6} value={formData.content} onChange={e => setFormData({...formData, content: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Category</label>
                <select value={formData.categoryId} onChange={e => setFormData({...formData, categoryId: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border">
                  <option value="general">General</option>
                  <option value="technology">Technology</option>
                  <option value="business">Business</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as any})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border">
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                  <option value="scheduled">Scheduled</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Featured Image</label>
              <div className="flex items-center gap-4">
                <input 
                  type="file" 
                  ref={featuredImageInputRef}
                  onChange={handleFeaturedImageChange}
                  accept="image/*"
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => featuredImageInputRef.current?.click()}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Select Image
                </button>
                {featuredImageFile && (
                  <span className="text-sm text-gray-500 truncate max-w-xs">{featuredImageFile.name}</span>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Event Gallery</label>
              <div className="flex flex-col gap-4">
                <input 
                  type="file" 
                  ref={galleryInputRef}
                  onChange={handleGalleryChange}
                  accept="image/*"
                  multiple
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => galleryInputRef.current?.click()}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 w-fit"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Add Gallery Images
                </button>
                
                {galleryFiles.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-2">
                    {galleryFiles.map((file, index) => (
                      <div key={index} className="relative group rounded-lg overflow-hidden border border-gray-200 bg-gray-50 aspect-w-1 aspect-h-1 flex items-center justify-center p-2">
                        <span className="text-xs text-gray-500 truncate w-full text-center">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => removeGalleryFile(index)}
                          className="absolute top-1 right-1 p-1 bg-red-100 text-red-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end mt-4">
              <button 
                type="submit" 
                disabled={isUploading}
                className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 disabled:opacity-50 flex items-center"
              >
                {isUploading ? 'Uploading & Saving...' : 'Save Post'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        {blogs.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No blog posts found. Create one to get started.
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {blogs.map((blog) => (
              <li key={blog.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center min-w-0 gap-4">
                    {blog.featuredImage ? (
                      <img src={blog.featuredImage} alt="" className="w-12 h-12 rounded-md object-cover" />
                    ) : (
                      <div className="w-12 h-12 rounded-md bg-indigo-50 flex items-center justify-center">
                        <FileText className="w-6 h-6 text-indigo-600" />
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 truncate">{blog.title}</h3>
                      <div className="mt-1 flex items-center gap-4 text-sm text-gray-500">
                        <span>{new Date(blog.createdAt).toLocaleDateString()}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          blog.status === 'published' ? 'bg-green-100 text-green-800' : 
                          blog.status === 'draft' ? 'bg-gray-100 text-gray-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {blog.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => handleEdit(blog)} className="p-2 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50">
                      <Edit className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleDelete(blog.id)} className="p-2 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
