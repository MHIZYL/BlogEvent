import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, deleteDoc, doc, orderBy, updateDoc, where } from 'firebase/firestore';
import { db } from '../../firebase';
import { MessageSquare, Trash2, ExternalLink, CheckCircle, AlertOctagon, Filter } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';
import { Link } from 'react-router-dom';
import { clsx } from 'clsx';

interface Comment {
  id: string;
  content: string;
  authorName: string;
  targetId: string;
  targetType: 'event' | 'blog';
  createdAt: any;
  status?: 'pending' | 'approved' | 'spam';
}

export default function AdminComments() {
  const [comments, setComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'spam'>('all');

  useEffect(() => {
    let q = query(collection(db, 'comments'), orderBy('createdAt', 'desc'));
    
    if (filter !== 'all') {
      q = query(collection(db, 'comments'), where('status', '==', filter), orderBy('createdAt', 'desc'));
    }
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Comment[];
      setComments(commentsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'comments');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this comment?')) {
      try {
        await deleteDoc(doc(db, 'comments', id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `comments/${id}`);
      }
    }
  };

  const handleStatusUpdate = async (id: string, status: 'approved' | 'spam') => {
    try {
      await updateDoc(doc(db, 'comments', id), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `comments/${id}`);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-gray-500">Loading comments...</div>;
  }

  return (
    <div className="p-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Comment Management</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Approve, delete, or mark comments as spam</p>
        </div>
        
        <div className="flex items-center gap-2 bg-white dark:bg-dark-surface p-1 rounded-lg border border-gray-200 dark:border-dark-border shadow-sm">
          {(['all', 'pending', 'approved', 'spam'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={clsx(
                "px-4 py-1.5 text-sm font-medium rounded-md transition-all capitalize",
                filter === f 
                  ? "bg-indigo-600 text-white shadow-md" 
                  : "text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-dark-bg"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white dark:bg-dark-surface rounded-xl shadow-sm border border-gray-200 dark:border-dark-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 dark:bg-dark-bg/50 border-b border-gray-200 dark:border-dark-border">
                <th className="p-4 font-medium text-gray-600 dark:text-gray-400">Author</th>
                <th className="p-4 font-medium text-gray-600 dark:text-gray-400">Comment</th>
                <th className="p-4 font-medium text-gray-600 dark:text-gray-400">Target</th>
                <th className="p-4 font-medium text-gray-600 dark:text-gray-400">Status</th>
                <th className="p-4 font-medium text-gray-600 dark:text-gray-400 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-dark-border">
              {comments.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-gray-500 dark:text-gray-400">
                    No comments found in this category.
                  </td>
                </tr>
              ) : (
                comments.map((comment) => (
                  <tr key={comment.id} className="hover:bg-gray-50 dark:hover:bg-dark-bg/30 transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-gray-900 dark:text-white">{comment.authorName}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleDateString() : 'N/A'}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="text-gray-600 dark:text-gray-300 max-w-md line-clamp-2" title={comment.content}>
                        {comment.content}
                      </div>
                    </td>
                    <td className="p-4">
                      <Link 
                        to={`/${comment.targetType === 'event' ? 'events' : 'blog'}/${comment.targetId}`}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 transition-colors"
                        target="_blank"
                      >
                        {comment.targetType === 'event' ? 'Event' : 'Blog'}
                        <ExternalLink className="w-3 h-3" />
                      </Link>
                    </td>
                    <td className="p-4">
                      <span className={clsx(
                        "px-2 py-1 rounded-md text-xs font-bold uppercase tracking-wider",
                        comment.status === 'approved' ? "bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400" :
                        comment.status === 'spam' ? "bg-red-100 text-red-700 dark:bg-red-900/20 dark:text-red-400" :
                        "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400"
                      )}>
                        {comment.status || 'pending'}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-2">
                        {comment.status !== 'approved' && (
                          <button
                            onClick={() => handleStatusUpdate(comment.id, 'approved')}
                            className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                            title="Approve Comment"
                          >
                            <CheckCircle className="w-5 h-5" />
                          </button>
                        )}
                        {comment.status !== 'spam' && (
                          <button
                            onClick={() => handleStatusUpdate(comment.id, 'spam')}
                            className="p-2 text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors"
                            title="Mark as Spam"
                          >
                            <AlertOctagon className="w-5 h-5" />
                          </button>
                        )}
                        <button
                          onClick={() => handleDelete(comment.id)}
                          className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                          title="Delete Comment"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
