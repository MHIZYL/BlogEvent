import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../../firebase';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { Users, Calendar, FileText, Eye, TrendingUp } from 'lucide-react';

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function AdminDashboard() {
  const [counts, setCounts] = useState({ events: 0, blogs: 0, users: 0, registrations: 0 });
  const [topEvents, setTopEvents] = useState<any[]>([]);
  const [categoryData, setCategoryData] = useState<any[]>([]);
  const [visitorData, setVisitorData] = useState<any[]>([]);

  useEffect(() => {
    // Basic counts
    const unsubEvents = onSnapshot(collection(db, 'events'), (snapshot) => {
      setCounts(prev => ({ ...prev, events: snapshot.size }));
      
      // Calculate category popularity
      const categories: Record<string, number> = {};
      snapshot.docs.forEach(doc => {
        const cat = doc.data().categoryId || 'General';
        categories[cat] = (categories[cat] || 0) + 1;
      });
      
      setCategoryData(Object.entries(categories).map(([name, value]) => ({ name, value })));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'events'));

    const unsubBlogs = onSnapshot(collection(db, 'blog_posts'), (snapshot) => {
      setCounts(prev => ({ ...prev, blogs: snapshot.size }));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'blog_posts'));

    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setCounts(prev => ({ ...prev, users: snapshot.size }));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'users'));

    const unsubRegs = onSnapshot(collection(db, 'registrations'), (snapshot) => {
      setCounts(prev => ({ ...prev, registrations: snapshot.size }));
    }, (error) => handleFirestoreError(error, OperationType.LIST, 'registrations'));

    // Top viewed events
    const topEventsQ = query(collection(db, 'events'), orderBy('views', 'desc'), limit(5));
    const unsubTopEvents = onSnapshot(topEventsQ, (snapshot) => {
      setTopEvents(snapshot.docs.map(doc => ({
        name: doc.data().title.substring(0, 20) + '...',
        views: doc.data().views || 0
      })));
    });

    // Daily visitors
    const fetchVisitors = async () => {
      try {
        const visitorsQ = query(collection(db, 'analytics'), orderBy('date', 'desc'), limit(7));
        const vSnap = await getDocs(visitorsQ);
        const vData = vSnap.docs.map(doc => ({
          date: doc.data().date.split('-').slice(1).join('/'), // MM/DD
          visitors: doc.data().count || 0
        })).reverse();
        setVisitorData(vData);
      } catch (error) {
        console.error("Error fetching visitors:", error);
      }
    };
    fetchVisitors();

    return () => {
      unsubEvents();
      unsubBlogs();
      unsubUsers();
      unsubRegs();
      unsubTopEvents();
    };
  }, []);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Analytics Overview</h2>
      
      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
          <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mr-4">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Events</h3>
            <p className="text-2xl font-bold text-gray-900">{counts.events}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
          <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 mr-4">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Total Users</h3>
            <p className="text-2xl font-bold text-gray-900">{counts.users}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
          <div className="w-12 h-12 bg-amber-50 rounded-full flex items-center justify-center text-amber-600 mr-4">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Event Registrations</h3>
            <p className="text-2xl font-bold text-gray-900">{counts.registrations}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center">
          <div className="w-12 h-12 bg-pink-50 rounded-full flex items-center justify-center text-pink-600 mr-4">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500">Blog Posts</h3>
            <p className="text-2xl font-bold text-gray-900">{counts.blogs}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Daily Visitors Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center mb-4">
            <Eye className="w-5 h-5 text-indigo-500 mr-2" />
            <h3 className="text-lg font-bold text-gray-900">Daily Visitors (Last 7 Days)</h3>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={visitorData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Line type="monotone" dataKey="visitors" stroke="#4f46e5" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Most Viewed Events */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center mb-4">
            <TrendingUp className="w-5 h-5 text-emerald-500 mr-2" />
            <h3 className="text-lg font-bold text-gray-900">Most Viewed Events</h3>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={topEvents} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f3f4f6" />
                <XAxis type="number" axisLine={false} tickLine={false} />
                <YAxis dataKey="name" type="category" width={100} axisLine={false} tickLine={false} fontSize={12} />
                <Tooltip cursor={{ fill: '#f3f4f6' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="views" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Popular Categories */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 lg:col-span-2">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Events by Category</h3>
          <div className="h-72 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={110}
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
