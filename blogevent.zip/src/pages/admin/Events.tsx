import React, { useState, useEffect, useRef } from 'react';
import { collection, query, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp, getDocs, getDoc, where, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase';
import { useAuth } from '../../contexts/AuthContext';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';
import { Calendar, MapPin, Trash2, Edit, Bell, Upload } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  date: string;
  time: string;
  location: string;
  organizer: string;
  image: string;
  status: 'upcoming' | 'completed' | 'draft';
  featured: boolean;
  createdBy: string;
}

export default function AdminEvents() {
  const { profile } = useAuth();
  const [events, setEvents] = useState<Event[]>([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageType, setImageType] = useState<'url' | 'upload'>('url');
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Omit<Event, 'id' | 'createdBy'>>({
    title: '',
    description: '',
    categoryId: 'general',
    date: '',
    time: '',
    location: '',
    organizer: '',
    image: '',
    status: 'upcoming',
    featured: false
  });

  useEffect(() => {
    const q = query(collection(db, 'events'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const eventsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Event[];
      setEvents(eventsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
    });

    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      let imageUrl = formData.image;
      if (imageType === 'upload' && imageFile) {
        const storageRef = ref(storage, `events/${Date.now()}_${imageFile.name}`);
        await uploadBytes(storageRef, imageFile);
        imageUrl = await getDownloadURL(storageRef);
      }

      const eventData = {
        title: formData.title || '',
        description: formData.description || '',
        categoryId: formData.categoryId || 'general',
        date: formData.date || '',
        time: formData.time || '',
        location: formData.location || '',
        organizer: formData.organizer || '',
        status: formData.status || 'upcoming',
        featured: formData.featured || false,
        image: imageUrl,
        createdBy: profile.uid,
        updatedAt: new Date().toISOString(),
      };

      if (editingId) {
        await updateDoc(doc(db, 'events', editingId), eventData);
      } else {
        const docRef = await addDoc(collection(db, 'events'), {
          ...eventData,
          createdAt: new Date().toISOString(),
          views: 0,
          registrationsCount: 0,
          tags: [],
          galleryImages: []
        });

        // Send email notification to all users (only for new events)
        const usersSnap = await getDocs(collection(db, 'users'));
        const emailPromises = usersSnap.docs.map(userDoc => {
          const userData = userDoc.data();
          if (userData.email && userData.notificationsEnabled !== false) {
            return addDoc(collection(db, 'mail'), {
              to: userData.email,
              message: {
                subject: `New Event: ${formData.title}`,
                html: `
                  <h2>A new event has been added to BlogEvent!</h2>
                  <p><strong>${formData.title}</strong></p>
                  <p>${formData.description.substring(0, 100)}...</p>
                  <ul>
                    <li><strong>Date:</strong> ${formData.date}</li>
                    <li><strong>Location:</strong> ${formData.location}</li>
                  </ul>
                  <p>Visit BlogEvent to register and secure your spot!</p>
                `
              }
            });
          }
          return Promise.resolve();
        });
        
        await Promise.all(emailPromises);
      }

      setIsFormOpen(false);
      setEditingId(null);
      setFormData({
        title: '', description: '', categoryId: 'general', date: '', time: '',
        location: '', organizer: '', image: '', status: 'upcoming', featured: false
      });
      setImageFile(null);
      setImageType('url');
      alert(editingId ? 'Event updated successfully!' : 'Event created successfully!');
    } catch (error) {
      const errorMsg = handleFirestoreError(error, editingId ? OperationType.UPDATE : OperationType.CREATE, 'events');
      alert(`Error saving event: ${JSON.parse(errorMsg).error}`);
    }
  };

  const handleEdit = (event: Event) => {
    const { id, createdBy, ...rest } = event;
    setFormData(rest);
    setEditingId(id);
    setImageType('url');
    setIsFormOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      try {
        await deleteDoc(doc(db, 'events', id));
        alert('Event deleted successfully!');
      } catch (error) {
        const errorMsg = handleFirestoreError(error, OperationType.DELETE, `events/${id}`);
        alert(`Error deleting event: ${JSON.parse(errorMsg).error}`);
      }
    }
  };

  const handleSendReminder = async (event: Event) => {
    if (window.confirm(`Send reminder email to all registered users for "${event.title}"?`)) {
      try {
        const registrationsSnap = await getDocs(query(collection(db, 'registrations'), where('eventId', '==', event.id)));
        
        const emailPromises = registrationsSnap.docs.map(async (regDoc) => {
          const regData = regDoc.data();
          const userDoc = await getDoc(doc(db, 'users', regData.userId));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            if (userData.email) {
              return addDoc(collection(db, 'mail'), {
                to: userData.email,
                message: {
                  subject: `Reminder: Upcoming Event - ${event.title}`,
                  html: `
                    <h2>Don't forget your upcoming event!</h2>
                    <p><strong>${event.title}</strong> is happening soon.</p>
                    <ul>
                      <li><strong>Date:</strong> ${event.date}</li>
                      <li><strong>Time:</strong> ${event.time}</li>
                      <li><strong>Location:</strong> ${event.location}</li>
                    </ul>
                    <p>Your Ticket ID: ${regData.ticketId}</p>
                    <p>We look forward to seeing you there!</p>
                  `
                }
              });
            }
          }
          return Promise.resolve();
        });

        await Promise.all(emailPromises);
        alert('Reminder emails sent successfully!');
      } catch (error) {
        console.error("Failed to send reminders:", error);
        alert('Failed to send reminders. Check console for details.');
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Manage Events</h2>
        <button 
          onClick={() => {
            if (isFormOpen) {
              setEditingId(null);
              setFormData({
                title: '', description: '', categoryId: 'general', date: '', time: '',
                location: '', organizer: '', image: '', status: 'upcoming', featured: false
              });
            }
            setIsFormOpen(!isFormOpen);
          }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
        >
          {isFormOpen ? 'Cancel' : 'Add Event'}
        </button>
      </div>

      {isFormOpen && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6">
          <h3 className="text-lg font-medium mb-4">{editingId ? 'Edit Event' : 'Create New Event'}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Title</label>
                <input type="text" required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Organizer</label>
                <input type="text" required value={formData.organizer} onChange={e => setFormData({...formData, organizer: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Date</label>
                <input type="date" required value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Time</label>
                <input type="time" required value={formData.time} onChange={e => setFormData({...formData, time: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Location</label>
                <input type="text" required value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Event Image</label>
                <div className="flex gap-4 mb-2">
                  <button type="button" onClick={() => setImageType('url')} className={`px-3 py-1 text-sm rounded ${imageType === 'url' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100'}`}>URL</button>
                  <button type="button" onClick={() => setImageType('upload')} className={`px-3 py-1 text-sm rounded ${imageType === 'upload' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100'}`}>Upload</button>
                </div>
                {imageType === 'url' ? (
                  <input type="url" value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" placeholder="https://..." />
                ) : (
                  <div className="flex items-center gap-4">
                    <input type="file" ref={imageInputRef} onChange={e => e.target.files && setImageFile(e.target.files[0])} accept="image/*" className="hidden" />
                    <button type="button" onClick={() => imageInputRef.current?.click()} className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                      <Upload className="w-4 h-4 mr-2" /> Select Image
                    </button>
                    {imageFile && <span className="text-sm text-gray-500">{imageFile.name}</span>}
                  </div>
                )}
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700">Description</label>
                <textarea required rows={3} value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as any})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2 border">
                  <option value="upcoming">Upcoming</option>
                  <option value="completed">Completed</option>
                  <option value="draft">Draft</option>
                </select>
              </div>
              <div className="flex items-center mt-6">
                <input type="checkbox" id="featured" checked={formData.featured} onChange={e => setFormData({...formData, featured: e.target.checked})} className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded" />
                <label htmlFor="featured" className="ml-2 block text-sm text-gray-900">Featured Event</label>
              </div>
            </div>
            <div className="flex justify-end mt-4">
              <button type="submit" className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                Save Event
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow-sm rounded-lg border border-gray-200 overflow-hidden">
        {events.length === 0 ? (
          <div className="p-6 text-center text-gray-500">
            No events found. Create one to get started.
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {events.map((event) => (
              <li key={event.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center min-w-0 gap-4">
                    {event.image ? (
                      <img src={event.image} alt="" className="w-16 h-16 rounded-md object-cover" />
                    ) : (
                      <div className="w-16 h-16 rounded-md bg-gray-200 flex items-center justify-center">
                        <Calendar className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-medium text-indigo-600 truncate">{event.title}</h3>
                      <div className="mt-1 flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center"><Calendar className="w-4 h-4 mr-1" /> {event.date}</span>
                        <span className="flex items-center"><MapPin className="w-4 h-4 mr-1" /> {event.location}</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          event.status === 'upcoming' ? 'bg-green-100 text-green-800' : 
                          event.status === 'completed' ? 'bg-gray-100 text-gray-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {event.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {event.status === 'upcoming' && (
                      <button 
                        onClick={() => handleSendReminder(event)}
                        className="p-2 text-gray-400 hover:text-yellow-600 rounded-full hover:bg-yellow-50"
                        title="Send Reminder Email"
                      >
                        <Bell className="w-5 h-5" />
                      </button>
                    )}
                    <button 
                      onClick={() => handleEdit(event)}
                      className="p-2 text-gray-400 hover:text-indigo-600 rounded-full hover:bg-indigo-50"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button onClick={() => handleDelete(event.id)} className="p-2 text-gray-400 hover:text-red-600 rounded-full hover:bg-red-50">
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
