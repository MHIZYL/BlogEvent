import React, { useState, useEffect, useRef } from 'react';
import { Save, Upload } from 'lucide-react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../../firebase';
import { handleFirestoreError, OperationType } from '../../utils/errorHandling';

export default function Settings() {
  const [settings, setSettings] = useState({
    siteDescription: 'Discover and register for amazing events.',
    contactEmail: 'support@eventhub.com',
    allowRegistration: true,
    maintenanceMode: false,
    heroImageUrl: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80',
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [heroImageFile, setHeroImageFile] = useState<File | null>(null);
  const [heroImageType, setHeroImageType] = useState<'url' | 'upload'>('url');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'general');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setSettings(prev => ({
            ...prev,
            siteDescription: data.siteDescription || prev.siteDescription,
            contactEmail: data.contactEmail || prev.contactEmail,
            allowRegistration: data.allowRegistration !== undefined ? data.allowRegistration : prev.allowRegistration,
            maintenanceMode: data.maintenanceMode !== undefined ? data.maintenanceMode : prev.maintenanceMode,
            heroImageUrl: data.heroImageUrl || prev.heroImageUrl,
          }));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'settings/general');
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      let finalHeroImageUrl = settings.heroImageUrl;

      if (heroImageType === 'upload' && heroImageFile) {
        const storageRef = ref(storage, `settings/hero_${Date.now()}_${heroImageFile.name}`);
        await uploadBytes(storageRef, heroImageFile);
        finalHeroImageUrl = await getDownloadURL(storageRef);
      }

      const updatedSettings = {
        ...settings,
        heroImageUrl: finalHeroImageUrl,
      };

      await setDoc(doc(db, 'settings', 'general'), updatedSettings);
      setSettings(updatedSettings);
      setHeroImageFile(null);
      setHeroImageType('url');
      alert('Settings saved successfully!');
    } catch (error) {
      const errorMsg = handleFirestoreError(error, OperationType.UPDATE, 'settings/general');
      alert(`Error saving settings: ${JSON.parse(errorMsg).error}`);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12">Loading settings...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">General Settings</h2>
        </div>
        
        <form onSubmit={handleSave} className="p-6 space-y-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Hero Image</label>
              <div className="flex gap-4 mb-3">
                <button 
                  type="button" 
                  onClick={() => setHeroImageType('url')} 
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${heroImageType === 'url' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                >
                  Image URL
                </button>
                <button 
                  type="button" 
                  onClick={() => setHeroImageType('upload')} 
                  className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${heroImageType === 'upload' ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                >
                  Upload Image
                </button>
              </div>

              {heroImageType === 'url' ? (
                <input
                  type="url"
                  value={settings.heroImageUrl}
                  onChange={(e) => setSettings({ ...settings, heroImageUrl: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
                />
              ) : (
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={(e) => e.target.files && setHeroImageFile(e.target.files[0])}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {heroImageFile ? 'Change Image' : 'Select Image'}
                  </button>
                  {heroImageFile && (
                    <span className="text-sm text-gray-500 truncate max-w-xs">{heroImageFile.name}</span>
                  )}
                </div>
              )}
              
              {settings.heroImageUrl && (
                <div className="mt-4">
                  <p className="text-xs text-gray-500 mb-2">Current Preview:</p>
                  <img src={settings.heroImageUrl} alt="Hero Preview" className="h-32 w-full object-cover rounded-lg border border-gray-200" />
                </div>
              )}
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Site Description</label>
              <textarea
                rows={3}
                value={settings.siteDescription}
                onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Contact Email</label>
              <input
                type="email"
                value={settings.contactEmail}
                onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
                className="mt-1 block w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-indigo-500 sm:text-sm"
              />
            </div>

            <div className="sm:col-span-2">
              <div className="flex items-start">
                <div className="flex h-5 items-center">
                  <input
                    id="allowRegistration"
                    type="checkbox"
                    checked={settings.allowRegistration}
                    onChange={(e) => setSettings({ ...settings, allowRegistration: e.target.checked })}
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="allowRegistration" className="font-medium text-gray-700">Allow User Registration</label>
                  <p className="text-gray-500">Enable or disable new user sign-ups.</p>
                </div>
              </div>
            </div>

            <div className="sm:col-span-2">
              <div className="flex items-start">
                <div className="flex h-5 items-center">
                  <input
                    id="maintenanceMode"
                    type="checkbox"
                    checked={settings.maintenanceMode}
                    onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                    className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="maintenanceMode" className="font-medium text-gray-700">Maintenance Mode</label>
                  <p className="text-gray-500">Put the site into maintenance mode (only admins can access).</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
