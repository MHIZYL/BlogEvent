import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, query, where, addDoc, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { FileText, MessageSquare, Send, Calendar, User } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';
import { useAuth } from '../contexts/AuthContext';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  categoryId: string;
  createdAt: string;
  authorId: string;
  authorName: string;
  image?: string;
  featuredImage?: string;
  gallery?: string[];
}

interface Comment {
  id: string;
  content: string;
  authorId: string;
  authorName: string;
  createdAt: any;
}

export default function BlogDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [blog, setBlog] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    if (!id) return;
    
    const fetchBlog = async () => {
      try {
        const docRef = doc(db, 'blog_posts', id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setBlog({ id: docSnap.id, ...docSnap.data() } as BlogPost);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `blog_posts/${id}`);
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  useEffect(() => {
    if (!id) return;

    const q = query(
      collection(db, 'comments'),
      where('targetId', '==', id),
      where('targetType', '==', 'blog'),
      where('status', '==', 'approved'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Comment[];
      setComments(commentsData);
    }, (error) => {
      console.error("Error fetching comments:", error);
    });

    return () => unsubscribe();
  }, [id]);

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) {
      navigate('/login');
      return;
    }
    if (!newComment.trim() || !id) return;

    setSubmittingComment(true);
    try {
      await addDoc(collection(db, 'comments'), {
        targetId: id,
        targetType: 'blog',
        content: newComment.trim(),
        authorId: profile.uid,
        authorName: profile.name || 'Anonymous',
        createdAt: new Date(),
        status: 'pending'
      });
      setNewComment('');
      alert('Your comment has been submitted and is awaiting moderation.');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'comments');
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-gray-500">Loading blog post...</div>;
  }

  if (!blog) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-gray-500">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Blog post not found</h2>
        <Link to="/blog" className="text-indigo-600 hover:text-indigo-800">Return to blog</Link>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="w-full h-64 md:h-96 bg-gray-200 relative">
        {(blog.featuredImage || blog.image) ? (
          <img src={blog.featuredImage || blog.image} alt={blog.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-indigo-900">
            <FileText className="w-24 h-24 text-indigo-200 opacity-50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <span className="inline-block px-3 py-1 bg-indigo-600 text-white text-sm font-semibold rounded-full mb-4 capitalize">
            {blog.categoryId || 'General'}
          </span>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">{blog.title}</h1>
          <div className="flex items-center text-indigo-100 text-sm gap-6">
            <div className="flex items-center">
              <User className="w-4 h-4 mr-2" />
              {blog.authorName || 'Admin'}
            </div>
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              {new Date(blog.createdAt).toLocaleDateString()}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="space-y-12">
          {/* Main Content */}
          <section>
            <div className="prose max-w-none text-gray-700 whitespace-pre-wrap text-lg leading-relaxed">
              {blog.content}
            </div>
          </section>

          {/* Event Gallery */}
          {blog.gallery && blog.gallery.length > 0 && (
            <section className="border-t border-gray-200 pt-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Event Gallery</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {blog.gallery.map((url, index) => (
                  <div key={index} className="aspect-w-1 aspect-h-1 rounded-lg overflow-hidden bg-gray-100">
                    <img src={url} alt={`Gallery image ${index + 1}`} className="object-cover w-full h-full hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Comments Section */}
          <section className="border-t border-gray-200 pt-8">
            <div className="flex items-center gap-2 mb-6">
              <MessageSquare className="w-6 h-6 text-indigo-600" />
              <h2 className="text-2xl font-bold text-gray-900">Discussion</h2>
              <span className="bg-gray-100 text-gray-600 py-0.5 px-2.5 rounded-full text-sm font-medium ml-2">
                {comments.length}
              </span>
            </div>

            {/* Comment Form */}
            <div className="mb-8">
              {profile ? (
                <form onSubmit={handleCommentSubmit} className="flex gap-4">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold flex-shrink-0">
                    {profile.name?.charAt(0) || 'U'}
                  </div>
                  <div className="flex-1 relative">
                    <textarea
                      rows={3}
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      placeholder="Share your thoughts..."
                      className="w-full rounded-xl border border-gray-300 px-4 py-3 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 resize-none pr-12"
                      required
                    />
                    <button
                      type="submit"
                      disabled={submittingComment || !newComment.trim()}
                      className="absolute bottom-3 right-3 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              ) : (
                <div className="bg-gray-50 rounded-xl p-6 text-center border border-gray-200">
                  <p className="text-gray-600 mb-4">Please log in to join the discussion.</p>
                  <Link to="/login" className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                    Log In
                  </Link>
                </div>
              )}
            </div>

            {/* Comments List */}
            <div className="space-y-6">
              {comments.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No comments yet. Be the first to share your thoughts!</p>
              ) : (
                comments.map((comment) => (
                  <div key={comment.id} className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-bold flex-shrink-0">
                      {comment.authorName.charAt(0)}
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-2xl p-4 border border-gray-100">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold text-gray-900">{comment.authorName}</h4>
                        <span className="text-xs text-gray-500">
                          {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleDateString() : 'Just now'}
                        </span>
                      </div>
                      <p className="text-gray-700 whitespace-pre-wrap">{comment.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
