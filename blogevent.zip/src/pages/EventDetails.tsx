import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, addDoc, deleteDoc, onSnapshot, orderBy, updateDoc, increment } from 'firebase/firestore';
import { db } from '../firebase';
import { Calendar, MapPin, Clock, User, Share2, BookmarkPlus, BookmarkCheck, MessageSquare, Send, QrCode } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';
import { useAuth } from '../contexts/AuthContext';
import { QRCodeSVG } from 'qrcode.react';
import CountdownTimer from '../components/CountdownTimer';

interface Event {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  date: string;
  time: string;
  location: string;
  organizer: string;
  image: string;
  status: string;
  views?: number;
}

interface Comment {
  id: string;
  content: string;
  authorId: string;
  authorName: string;
  createdAt: any;
}

export default function EventDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [event, setEvent] = useState<Event | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSaved, setIsSaved] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [userTicketId, setUserTicketId] = useState<string | null>(null);
  const [savedEventId, setSavedEventId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  useEffect(() => {
    if (!id) return;
    
    const fetchEvent = async () => {
      try {
        const docRef = doc(db, 'events', id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setEvent({ id: docSnap.id, ...docSnap.data() } as Event);
          
          // Increment views
          if (!sessionStorage.getItem(`viewed_${id}`)) {
            await updateDoc(docRef, { views: increment(1) });
            sessionStorage.setItem(`viewed_${id}`, 'true');
          }
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `events/${id}`);
      } finally {
        setLoading(false);
      }
    };

    fetchEvent();
  }, [id]);

  useEffect(() => {
    if (!id || !profile) return;

    const checkUserStatus = async () => {
      try {
        // Check saved status
        const savedQ = query(collection(db, 'saved_events'), where('userId', '==', profile.uid), where('eventId', '==', id));
        const savedSnap = await getDocs(savedQ);
        if (!savedSnap.empty) {
          setIsSaved(true);
          setSavedEventId(savedSnap.docs[0].id);
        }

        // Check registration status
        const regQ = query(collection(db, 'registrations'), where('userId', '==', profile.uid), where('eventId', '==', id));
        const regSnap = await getDocs(regQ);
        if (!regSnap.empty) {
          setIsRegistered(true);
          setUserTicketId(regSnap.docs[0].data().ticketId);
        }
      } catch (error) {
        console.error("Error checking user status:", error);
      }
    };

    checkUserStatus();
  }, [id, profile]);

  useEffect(() => {
    if (!id) return;

    const q = query(
      collection(db, 'comments'),
      where('targetId', '==', id),
      where('targetType', '==', 'event'),
      where('status', '==', 'approved'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const commentsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Comment[];
      setComments(commentsData);
    }, (error) => {
      console.error("Error fetching comments:", error);
    });

    return () => unsubscribe();
  }, [id]);

  const handleSaveEvent = async () => {
    if (!profile) {
      navigate('/login');
      return;
    }

    if (!id) return;
    setIsProcessing(true);

    try {
      if (isSaved && savedEventId) {
        await deleteDoc(doc(db, 'saved_events', savedEventId));
        setIsSaved(false);
        setSavedEventId(null);
      } else {
        const docRef = await addDoc(collection(db, 'saved_events'), {
          userId: profile.uid,
          eventId: id
        });
        setIsSaved(true);
        setSavedEventId(docRef.id);
      }
    } catch (error) {
      handleFirestoreError(error, isSaved ? OperationType.DELETE : OperationType.CREATE, 'saved_events');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRegisterEvent = async () => {
    if (!profile) {
      navigate('/login');
      return;
    }

    if (!id || isRegistered) return;
    setIsProcessing(true);

    try {
      const ticketId = `TKT-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
      await addDoc(collection(db, 'registrations'), {
        eventId: id,
        userId: profile.uid,
        name: profile.name || 'User',
        email: profile.email,
        ticketId
      });
      
      // Create notification
      await addDoc(collection(db, 'notifications'), {
        userId: profile.uid,
        title: 'Event Registration Successful',
        message: `You have successfully registered for "${event?.title}". Your ticket ID is ${ticketId}.`,
        read: false,
        createdAt: new Date(),
        type: 'event',
        link: `/events/${id}`
      });

      // Simulate sending email via Firebase Trigger Email extension
      await addDoc(collection(db, 'mail'), {
        to: profile.email,
        message: {
          subject: `Ticket Confirmation: ${event?.title}`,
          html: `
            <h2>You're going to ${event?.title}!</h2>
            <p>Hi ${profile.name},</p>
            <p>Your registration is confirmed. Here are your event details:</p>
            <ul>
              <li><strong>Date:</strong> ${event?.date}</li>
              <li><strong>Time:</strong> ${event?.time}</li>
              <li><strong>Location:</strong> ${event?.location}</li>
            </ul>
            <p><strong>Your Ticket ID:</strong> ${ticketId}</p>
            <p>Please keep this email for your records.</p>
          `
        }
      });

      setIsRegistered(true);
      setUserTicketId(ticketId);
      alert('Successfully registered for the event! Check your email for confirmation.');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'registrations');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: event?.title,
        text: 'Check out this event!',
        url: window.location.href,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleCommentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) {
      navigate('/login');
      return;
    }
    if (!newComment.trim() || !id) return;

    setSubmittingComment(true);
    try {
      await addDoc(collection(db, 'comments'), {
        targetId: id,
        targetType: 'event',
        content: newComment.trim(),
        authorId: profile.uid,
        authorName: profile.name || 'Anonymous',
        createdAt: new Date(),
        status: 'pending'
      });
      setNewComment('');
      alert('Your comment has been submitted and is awaiting moderation.');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'comments');
    } finally {
      setSubmittingComment(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-gray-500">Loading event details...</div>;
  }

  if (!event) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-gray-500">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Event not found</h2>
        <Link to="/events" className="text-indigo-600 hover:text-indigo-800">Return to events</Link>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Image */}
      <div className="w-full h-64 md:h-96 bg-gray-200 relative">
        {event.image ? (
          <img src={event.image} alt={event.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-indigo-900">
            <Calendar className="w-24 h-24 text-indigo-200 opacity-50" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <span className="inline-block px-3 py-1 bg-indigo-600 text-white text-sm font-semibold rounded-full mb-4 capitalize">
            {event.categoryId || 'General'}
          </span>
          <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{event.title}</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-12">
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">About this event</h2>
              <div className="prose max-w-none text-gray-600 whitespace-pre-wrap">
                {event.description}
              </div>
            </section>

            {/* Comments Section */}
            <section className="border-t border-gray-200 pt-8">
              <div className="flex items-center gap-2 mb-6">
                <MessageSquare className="w-6 h-6 text-indigo-600" />
                <h2 className="text-2xl font-bold text-gray-900">Discussion</h2>
                <span className="bg-gray-100 text-gray-600 py-0.5 px-2.5 rounded-full text-sm font-medium ml-2">
                  {comments.length}
                </span>
              </div>

              {/* Comment Form */}
              <div className="mb-8">
                {profile ? (
                  <form onSubmit={handleCommentSubmit} className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold flex-shrink-0">
                      {profile.name?.charAt(0) || 'U'}
                    </div>
                    <div className="flex-1 relative">
                      <textarea
                        rows={3}
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Add a comment..."
                        className="w-full rounded-xl border border-gray-300 px-4 py-3 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 resize-none pr-12"
                        required
                      />
                      <button
                        type="submit"
                        disabled={submittingComment || !newComment.trim()}
                        className="absolute bottom-3 right-3 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="bg-gray-50 rounded-xl p-6 text-center border border-gray-200">
                    <p className="text-gray-600 mb-4">Please log in to join the discussion.</p>
                    <Link to="/login" className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                      Log In
                    </Link>
                  </div>
                )}
              </div>

              {/* Comments List */}
              <div className="space-y-6">
                {comments.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No comments yet. Be the first to start the discussion!</p>
                ) : (
                  comments.map((comment) => (
                    <div key={comment.id} className="flex gap-4">
                      <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-bold flex-shrink-0">
                        {comment.authorName.charAt(0)}
                      </div>
                      <div className="flex-1 bg-gray-50 rounded-2xl p-4 border border-gray-100">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-semibold text-gray-900">{comment.authorName}</h4>
                          <span className="text-xs text-gray-500">
                            {comment.createdAt?.toDate ? comment.createdAt.toDate().toLocaleDateString() : 'Just now'}
                          </span>
                        </div>
                        <p className="text-gray-700 whitespace-pre-wrap">{comment.content}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </section>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-6">Event Details</h3>
              
              {event.status === 'upcoming' && (
                <div className="mb-8 pb-8 border-b border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4 text-center">Event Starts In</h4>
                  <CountdownTimer 
                    date={event.date} 
                    time={event.time} 
                    onComplete={async () => {
                      if (event.id) {
                        try {
                          await updateDoc(doc(db, 'events', event.id), { status: 'ongoing' });
                          setEvent(prev => prev ? { ...prev, status: 'ongoing' } : null);
                        } catch (error) {
                          console.error("Failed to update event status:", error);
                        }
                      }
                    }}
                  />
                </div>
              )}

              <div className="space-y-6">
                <div className="flex items-start">
                  <Calendar className="w-6 h-6 text-indigo-600 mt-1 mr-4" />
                  <div>
                    <p className="font-medium text-gray-900">Date</p>
                    <p className="text-gray-600">{event.date}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clock className="w-6 h-6 text-indigo-600 mt-1 mr-4" />
                  <div>
                    <p className="font-medium text-gray-900">Time</p>
                    <p className="text-gray-600">{event.time}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <MapPin className="w-6 h-6 text-indigo-600 mt-1 mr-4" />
                  <div>
                    <p className="font-medium text-gray-900">Location</p>
                    <p className="text-gray-600">{event.location}</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <User className="w-6 h-6 text-indigo-600 mt-1 mr-4" />
                  <div>
                    <p className="font-medium text-gray-900">Organizer</p>
                    <p className="text-gray-600">{event.organizer}</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-gray-200 space-y-4">
                {isRegistered && userTicketId ? (
                  <div className="bg-indigo-50 rounded-xl p-6 text-center border border-indigo-100">
                    <h4 className="font-bold text-indigo-900 mb-2">Your Ticket</h4>
                    <div className="bg-white p-4 rounded-lg inline-block shadow-sm mb-3">
                      <QRCodeSVG value={userTicketId} size={120} />
                    </div>
                    <p className="text-sm font-mono text-indigo-700 bg-indigo-100 py-1 px-3 rounded-md inline-block">
                      {userTicketId}
                    </p>
                    <p className="text-xs text-indigo-600 mt-3">Present this QR code at the event</p>
                  </div>
                ) : (
                  <button 
                    onClick={handleRegisterEvent}
                    disabled={isProcessing}
                    className="w-full font-semibold py-3 px-4 rounded-xl transition-colors shadow-sm bg-indigo-600 text-white hover:bg-indigo-700"
                  >
                    Register Now
                  </button>
                )}
                <div className="flex gap-4">
                  <button 
                    onClick={handleSaveEvent}
                    disabled={isProcessing}
                    className={`flex-1 flex items-center justify-center gap-2 border font-medium py-2 px-4 rounded-xl transition-colors ${
                      isSaved 
                        ? 'bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100' 
                        : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {isSaved ? <BookmarkCheck className="w-5 h-5" /> : <BookmarkPlus className="w-5 h-5" />} 
                    {isSaved ? 'Saved' : 'Save'}
                  </button>
                  <button 
                    onClick={handleShare}
                    className="flex-1 flex items-center justify-center gap-2 bg-white border border-gray-300 text-gray-700 font-medium py-2 px-4 rounded-xl hover:bg-gray-50 transition-colors"
                  >
                    <Share2 className="w-5 h-5" /> Share
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
