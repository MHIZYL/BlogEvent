import { useState, useEffect } from 'react';
import { collection, query, onSnapshot, where } from 'firebase/firestore';
import { db } from '../firebase';
import { FileText } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';
import { Link } from 'react-router-dom';

interface BlogPost {
  id: string;
  title: string;
  content: string;
  categoryId: string;
  createdAt: string;
  featuredImage?: string;
  image?: string;
}

export default function Blog() {
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'blog_posts'), where('status', '==', 'published'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const blogsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as BlogPost[];
      setBlogs(blogsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'blog_posts');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Event Blog</h1>
      
      {loading ? (
        <div className="text-center py-20 text-gray-500">Loading blog posts...</div>
      ) : blogs.length === 0 ? (
        <div className="text-center py-20 text-gray-500 bg-white rounded-lg border border-gray-200">
          No blog posts found. Check back later!
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs.map((blog) => (
            <Link key={blog.id} to={`/blog/${blog.id}`} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow flex flex-col group">
              {(blog.featuredImage || blog.image) ? (
                <div className="h-48 bg-gray-200 w-full">
                  <img src={blog.featuredImage || blog.image} alt={blog.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              ) : (
                <div className="h-48 bg-indigo-50 flex items-center justify-center">
                  <FileText className="w-16 h-16 text-indigo-200" />
                </div>
              )}
              <div className="p-6 flex-1 flex flex-col">
                <div className="text-sm text-indigo-600 font-semibold mb-2 capitalize">{blog.categoryId || 'General'}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors">{blog.title}</h3>
                <p className="text-gray-500 text-sm mb-4 line-clamp-3">{blog.content}</p>
                <div className="mt-auto pt-4 border-t border-gray-100 flex items-center justify-between">
                  <span className="text-sm text-gray-500">{new Date(blog.createdAt).toLocaleDateString()}</span>
                  <span className="text-indigo-600 font-medium">Read more &rarr;</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
