import { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { Calendar, MapPin, Clock, Bookmark, Ticket, Download } from 'lucide-react';
import { Link } from 'react-router-dom';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';
import { QRCodeSVG } from 'qrcode.react';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  image: string;
  ticketId?: string;
}

export default function UserDashboard() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'registered' | 'saved'>('registered');
  const [registeredEvents, setRegisteredEvents] = useState<Event[]>([]);
  const [savedEvents, setSavedEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    const fetchUserData = async () => {
      setLoading(true);
      try {
        // Fetch registered events
        const regQ = query(collection(db, 'registrations'), where('userId', '==', profile.uid));
        const regSnap = await getDocs(regQ);
        const regData = regSnap.docs.map(doc => ({ eventId: doc.data().eventId, ticketId: doc.data().ticketId }));
        
        const regEventsData: Event[] = [];
        for (const data of regData) {
          const eventDoc = await getDoc(doc(db, 'events', data.eventId));
          if (eventDoc.exists()) {
            regEventsData.push({ id: eventDoc.id, ...eventDoc.data(), ticketId: data.ticketId } as Event);
          }
        }
        setRegisteredEvents(regEventsData);

        // Fetch saved events
        const savedQ = query(collection(db, 'saved_events'), where('userId', '==', profile.uid));
        const savedSnap = await getDocs(savedQ);
        const savedEventIds = savedSnap.docs.map(doc => doc.data().eventId);
        
        const savedEventsData: Event[] = [];
        for (const eventId of savedEventIds) {
          const eventDoc = await getDoc(doc(db, 'events', eventId));
          if (eventDoc.exists()) {
            savedEventsData.push({ id: eventDoc.id, ...eventDoc.data() } as Event);
          }
        }
        setSavedEvents(savedEventsData);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'user_dashboard_data');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [profile]);

  const displayEvents = activeTab === 'registered' ? registeredEvents : savedEvents;

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="flex items-center gap-6 mb-8">
        <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-2xl font-bold">
          {profile?.name?.charAt(0) || 'U'}
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome, {profile?.name || 'User'}</h1>
          <p className="text-gray-500">{profile?.email}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            <button
              onClick={() => setActiveTab('registered')}
              className={`w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm flex items-center justify-center gap-2 ${
                activeTab === 'registered'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Ticket className="w-5 h-5" />
              Registered Events
            </button>
            <button
              onClick={() => setActiveTab('saved')}
              className={`w-1/2 py-4 px-1 text-center border-b-2 font-medium text-sm flex items-center justify-center gap-2 ${
                activeTab === 'saved'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Bookmark className="w-5 h-5" />
              Saved Events
            </button>
          </nav>
        </div>

        <div className="p-6">
          {loading ? (
            <div className="text-center py-12 text-gray-500">Loading your events...</div>
          ) : displayEvents.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <p className="mb-4">No {activeTab} events found.</p>
              <Link to="/events" className="text-indigo-600 hover:text-indigo-800 font-medium">
                Browse Events &rarr;
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {displayEvents.map((event) => (
                <Link key={event.id} to={`/events/${event.id}`} className="group relative bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                  <div className="h-40 bg-gray-200 relative">
                    {event.image ? (
                      <img src={event.image} alt={event.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-indigo-900">
                        <Calendar className="w-12 h-12 text-indigo-200 opacity-50" />
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-bold text-gray-900 mb-2 truncate group-hover:text-indigo-600 transition-colors">{event.title}</h3>
                    <div className="space-y-2 text-sm text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-indigo-500" />
                        {event.date}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-indigo-500" />
                        {event.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-indigo-500" />
                        <span className="truncate">{event.location}</span>
                      </div>
                      {event.ticketId && (
                        <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col items-center">
                          <div className="bg-white p-2 rounded-lg shadow-sm border border-gray-100 mb-2">
                            <QRCodeSVG id={`qr-${event.ticketId}`} value={event.ticketId} size={80} />
                          </div>
                          <div className="flex items-center justify-between w-full">
                            <div className="flex items-center">
                              <Ticket className="w-4 h-4 mr-2 text-indigo-500" />
                              <span className="font-mono text-xs bg-indigo-50 text-indigo-700 px-2 py-1 rounded">
                                {event.ticketId}
                              </span>
                            </div>
                            <button 
                              onClick={(e) => {
                                e.preventDefault();
                                const svg = document.getElementById(`qr-${event.ticketId}`);
                                if (svg) {
                                  const svgData = new XMLSerializer().serializeToString(svg);
                                  const canvas = document.createElement('canvas');
                                  const ctx = canvas.getContext('2d');
                                  const img = new Image();
                                  img.onload = () => {
                                    canvas.width = img.width;
                                    canvas.height = img.height;
                                    ctx?.drawImage(img, 0, 0);
                                    const pngFile = canvas.toDataURL('image/png');
                                    const downloadLink = document.createElement('a');
                                    downloadLink.download = `ticket-${event.ticketId}.png`;
                                    downloadLink.href = `${pngFile}`;
                                    downloadLink.click();
                                  };
                                  img.src = `data:image/svg+xml;base64,${btoa(svgData)}`;
                                }
                              }}
                              className="text-indigo-600 hover:text-indigo-800 p-1 rounded-full hover:bg-indigo-50 transition-colors"
                              title="Download Ticket"
                            >
                              <Download className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
