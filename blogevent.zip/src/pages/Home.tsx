import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, MapPin, Clock, ArrowRight, Users, Star, Shield } from 'lucide-react';
import { collection, query, onSnapshot, where, limit, doc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';
import CountdownTimer from '../components/CountdownTimer';
import { motion } from 'motion/react';

interface Event {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  date: string;
  time: string;
  location: string;
  image: string;
}

export default function Home() {
  const [heroImageUrl, setHeroImageUrl] = useState('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80');
  const [siteDescription, setSiteDescription] = useState('Join thousands of people who use BlogEvent to find, register, and attend the best events, conferences, and meetups around the world.');

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, 'settings', 'general');
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.heroImageUrl) setHeroImageUrl(data.heroImageUrl);
          if (data.siteDescription) setSiteDescription(data.siteDescription);
        }
      } catch (error) {
        console.error("Error fetching settings:", error);
      }
    };
    fetchSettings();
  }, []);
  const [featuredEvents, setFeaturedEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, 'events'), 
      where('status', '==', 'upcoming'),
      limit(3)
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const eventsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Event[];
      setFeaturedEvents(eventsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return (
    <div className="bg-white dark:bg-dark-bg transition-colors duration-300">
      {/* Hero Section */}
      <div className="relative bg-indigo-900 overflow-hidden">
        <motion.div 
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.4 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0"
        >
          <img
            className="w-full h-full object-cover"
            src={heroImageUrl}
            alt="Vibrant event crowd"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
              Discover Amazing Events
            </h1>
            <p className="mt-6 text-xl text-indigo-100 max-w-3xl">
              {siteDescription}
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/events" className="inline-flex items-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-indigo-700 bg-white hover:bg-indigo-50 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1">
                Explore Events
              </Link>
              <Link to="/categories" className="inline-flex items-center px-8 py-4 border border-white/30 text-base font-bold rounded-xl text-white bg-white/10 backdrop-blur-md hover:bg-white/20 transition-all hover:-translate-y-1">
                Browse Categories
              </Link>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Countdown Timer Section */}
      {featuredEvents.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-indigo-600 py-12 relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <div className="absolute top-[-10%] left-[-5%] w-64 h-64 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-[-10%] right-[-5%] w-64 h-64 bg-white rounded-full blur-3xl"></div>
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-8">Next Big Event Starts In:</h2>
              <CountdownTimer 
                date={featuredEvents[0].date} 
                time={featuredEvents[0].time} 
                onComplete={async () => {
                  try {
                    await updateDoc(doc(db, 'events', featuredEvents[0].id), { status: 'ongoing' });
                  } catch (error) {
                    console.error("Failed to update event status:", error);
                  }
                }}
              />
              <p className="text-indigo-100 mt-8 text-lg font-medium">{featuredEvents[0].title}</p>
              <Link to={`/events/${featuredEvents[0].id}`} className="mt-4 inline-block text-white underline hover:text-indigo-200">
                View Event Details
              </Link>
            </div>
          </div>
        </motion.div>
      )}

      {/* Featured Events */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-4">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">Featured Events</h2>
            <p className="mt-2 text-lg text-gray-500 dark:text-gray-400">Don't miss out on our most popular upcoming events.</p>
          </div>
          <Link to="/events" className="flex items-center text-indigo-600 dark:text-indigo-400 hover:text-indigo-500 font-bold group">
            View all <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading events...</div>
        ) : featuredEvents.length === 0 ? (
          <div className="text-center py-12 text-gray-500 bg-gray-50 dark:bg-dark-surface rounded-2xl border border-gray-100 dark:border-dark-border">
            No upcoming events found. Check back later!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredEvents.map((event, index) => (
              <motion.div 
                key={event.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white dark:bg-dark-surface rounded-2xl shadow-sm border border-gray-100 dark:border-dark-border overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col group"
              >
                <div className="h-56 bg-gray-200 dark:bg-dark-bg relative overflow-hidden">
                  {event.image ? (
                    <img src={event.image} alt={event.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-indigo-50 dark:bg-indigo-900/20">
                      <Calendar className="w-12 h-12 text-indigo-200 dark:text-indigo-800" />
                    </div>
                  )}
                  <div className="absolute top-4 right-4 bg-white/90 dark:bg-dark-surface/90 backdrop-blur-sm px-4 py-1.5 rounded-full text-xs font-bold text-indigo-600 dark:text-indigo-400 shadow-sm capitalize">
                    {event.categoryId || 'General'}
                  </div>
                </div>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{event.title}</h3>
                  <p className="text-gray-500 dark:text-gray-400 text-sm mb-6 line-clamp-2">{event.description}</p>
                  
                  <div className="space-y-3 mb-8 mt-auto">
                    <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center mr-3">
                        <Calendar className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <span className="font-medium">{event.date}</span>
                    </div>
                    <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center mr-3">
                        <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <span className="font-medium">{event.time}</span>
                    </div>
                    <div className="flex items-center text-gray-500 dark:text-gray-400 text-sm">
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center mr-3">
                        <MapPin className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      </div>
                      <span className="truncate font-medium">{event.location}</span>
                    </div>
                  </div>
                  
                  <Link to={`/events/${event.id}`} className="block w-full text-center bg-indigo-600 text-white font-bold py-3 rounded-xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 dark:shadow-none transition-all hover:-translate-y-1">
                    View Details
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Quick About Section */}
      <div className="bg-gray-50 dark:bg-dark-surface/30 py-16 sm:py-24 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">Why Choose BlogEvent?</h2>
            <p className="mt-4 text-lg text-gray-500 dark:text-gray-400">We provide the best platform for discovering and managing events of all sizes.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[
              { icon: Users, title: 'Community Driven', desc: 'Connect with like-minded individuals and grow your professional network.' },
              { icon: Star, title: 'Premium Events', desc: 'Access exclusive, high-quality events curated by top organizers.' },
              { icon: Shield, title: 'Secure Ticketing', desc: 'Safe and reliable registration process with instant ticket delivery.' }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-8 rounded-3xl bg-white dark:bg-dark-surface border border-gray-100 dark:border-dark-border shadow-sm hover:shadow-xl transition-all duration-300"
              >
                <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mx-auto mb-6 transform rotate-3 group-hover:rotate-0 transition-transform">
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{feature.title}</h3>
                <p className="text-gray-500 dark:text-gray-400">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-indigo-700 dark:bg-indigo-900 rounded-[3rem] shadow-2xl overflow-hidden relative"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl -ml-32 -mb-32"></div>
            
            <div className="px-6 py-12 sm:px-12 sm:py-16 lg:flex lg:items-center lg:p-20 relative z-10">
              <div className="lg:w-0 lg:flex-1">
                <h2 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
                  Sign up for our newsletter
                </h2>
                <p className="mt-4 max-w-3xl text-lg text-indigo-100">
                  Get notified about new events, exclusive discounts, and community updates.
                </p>
              </div>
              <div className="mt-12 sm:w-full sm:max-w-md lg:mt-0 lg:ml-8 lg:flex-1">
                <form className="sm:flex gap-3" onSubmit={(e) => e.preventDefault()}>
                  <label htmlFor="email-address" className="sr-only">Email address</label>
                  <input id="email-address" name="email" type="email" autoComplete="email" required className="w-full border-transparent px-5 py-4 placeholder-gray-500 focus:ring-2 focus:ring-white rounded-xl bg-white/90 backdrop-blur-sm text-gray-900" placeholder="Enter your email" />
                  <button type="submit" className="mt-3 w-full flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-indigo-700 bg-white hover:bg-indigo-50 shadow-lg transition-all hover:-translate-y-1 sm:mt-0 sm:w-auto sm:flex-shrink-0">
                    Notify me
                  </button>
                </form>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
