import React, { useState, useEffect } from 'react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Search as SearchIcon, Calendar, MapPin, Clock } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  image: string;
  categoryId: string;
}

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [allEvents, setAllEvents] = useState<Event[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const q = query(collection(db, 'events'));
        const snapshot = await getDocs(q);
        const eventsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Event[];
        setAllEvents(eventsData);
        setLoading(false);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'events');
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  useEffect(() => {
    if (initialQuery && allEvents.length > 0) {
      handleSearch(initialQuery);
    } else if (!initialQuery) {
      setFilteredEvents(allEvents);
    }
  }, [initialQuery, allEvents]);

  const handleSearch = (queryStr: string) => {
    const lowerCaseQuery = queryStr.toLowerCase();
    const results = allEvents.filter(event => 
      event.title.toLowerCase().includes(lowerCaseQuery) ||
      event.description.toLowerCase().includes(lowerCaseQuery) ||
      event.location.toLowerCase().includes(lowerCaseQuery) ||
      (event.categoryId && event.categoryId.toLowerCase().includes(lowerCaseQuery))
    );
    setFilteredEvents(results);
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: searchQuery });
    handleSearch(searchQuery);
  };

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Search Events</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Find the perfect event by searching for keywords, locations, or categories.
        </p>
      </div>

      <div className="max-w-3xl mx-auto mb-12">
        <form onSubmit={onSubmit} className="relative">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <SearchIcon className="h-6 w-6 text-gray-400" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-12 pr-32 py-4 border border-gray-300 rounded-full leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-lg shadow-sm"
            placeholder="Search events, locations, or categories..."
          />
          <button
            type="submit"
            className="absolute inset-y-2 right-2 px-6 bg-indigo-600 text-white font-medium rounded-full hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            Search
          </button>
        </form>
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-500">Searching events...</div>
      ) : (
        <div>
          <div className="mb-6 text-gray-600 font-medium">
            {filteredEvents.length} {filteredEvents.length === 1 ? 'result' : 'results'} found
            {initialQuery && <span> for "{initialQuery}"</span>}
          </div>

          {filteredEvents.length === 0 ? (
            <div className="text-center py-20 bg-gray-50 rounded-2xl border border-gray-100">
              <SearchIcon className="mx-auto h-12 w-12 text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No events found</h3>
              <p className="text-gray-500">Try adjusting your search terms or browse all events.</p>
              <Link to="/events" className="mt-4 inline-block text-indigo-600 hover:text-indigo-800 font-medium">
                View all events &rarr;
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredEvents.map((event) => (
                <Link key={event.id} to={`/events/${event.id}`} className="group bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow flex flex-col">
                  <div className="h-48 bg-gray-200 relative overflow-hidden">
                    {event.image ? (
                      <img src={event.image} alt={event.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-indigo-900">
                        <Calendar className="w-16 h-16 text-indigo-200 opacity-50" />
                      </div>
                    )}
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-indigo-600 text-xs font-bold rounded-full uppercase tracking-wider">
                        {event.categoryId || 'General'}
                      </span>
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors line-clamp-2">{event.title}</h3>
                    <p className="text-gray-500 text-sm mb-4 line-clamp-2">{event.description}</p>
                    
                    <div className="mt-auto space-y-2 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-2 text-indigo-500" />
                        {event.date}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-indigo-500" />
                        {event.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-indigo-500" />
                        <span className="truncate">{event.location}</span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
