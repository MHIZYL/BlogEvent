import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Link } from 'react-router-dom';
import { Music, Laptop, Briefcase, Heart, Coffee, Globe, Calendar } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../utils/errorHandling';

interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  count: number;
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  technology: <Laptop className="w-8 h-8" />,
  business: <Briefcase className="w-8 h-8" />,
  health: <Heart className="w-8 h-8" />,
  entertainment: <Music className="w-8 h-8" />,
  lifestyle: <Coffee className="w-8 h-8" />,
  general: <Globe className="w-8 h-8" />
};

export default function Categories() {
  const [categories, setCategories] = useState<Category[]>([
    { id: 'technology', name: 'Technology', icon: 'technology', description: 'Tech conferences, hackathons, and meetups.', count: 0 },
    { id: 'business', name: 'Business', icon: 'business', description: 'Networking, seminars, and workshops.', count: 0 },
    { id: 'health', name: 'Health & Wellness', icon: 'health', description: 'Fitness classes, mental health workshops.', count: 0 },
    { id: 'entertainment', name: 'Entertainment', icon: 'entertainment', description: 'Concerts, festivals, and shows.', count: 0 },
    { id: 'lifestyle', name: 'Lifestyle', icon: 'lifestyle', description: 'Food, travel, and culture events.', count: 0 },
    { id: 'general', name: 'General', icon: 'general', description: 'Other miscellaneous events.', count: 0 }
  ]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategoryCounts = async () => {
      try {
        const updatedCategories = await Promise.all(
          categories.map(async (cat) => {
            const q = query(collection(db, 'events'), where('categoryId', '==', cat.id));
            const snapshot = await getDocs(q);
            return { ...cat, count: snapshot.size };
          })
        );
        setCategories(updatedCategories);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'events');
      } finally {
        setLoading(false);
      }
    };

    fetchCategoryCounts();
  }, []);

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Event Categories</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Browse events by category to find exactly what you're looking for.
        </p>
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-500">Loading categories...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category) => (
            <Link 
              key={category.id} 
              to={`/search?q=${category.id}`}
              className="group bg-white rounded-2xl shadow-sm border border-gray-100 p-8 hover:shadow-md hover:border-indigo-100 transition-all text-center flex flex-col items-center"
            >
              <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300">
                {CATEGORY_ICONS[category.icon] || <Calendar className="w-8 h-8" />}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{category.name}</h3>
              <p className="text-gray-500 text-sm mb-4">{category.description}</p>
              <div className="mt-auto">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800 group-hover:bg-indigo-50 group-hover:text-indigo-700 transition-colors">
                  {category.count} {category.count === 1 ? 'Event' : 'Events'}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
